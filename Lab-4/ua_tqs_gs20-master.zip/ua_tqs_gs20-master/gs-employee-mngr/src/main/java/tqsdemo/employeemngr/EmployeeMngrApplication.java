package tqsdemo.employeemngr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeMngrApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeMngrApplication.class, args);
    }

}
